# bricks-form-data-handler
Form submission handler for Bricks Builder - Saves data directly to Excel/XML files
